const todos =  [
    {
        id: 1,
        title: "go out for lunch"
    },
    {
        id: 2,
        title: "cut the cake for tea"
    }
];

module.exports.db = todos;